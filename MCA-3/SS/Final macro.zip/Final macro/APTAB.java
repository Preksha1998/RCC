class APTAB{
	String actualParameter;
	
	void insert(String str){
		actualParameter = str;
	}
}