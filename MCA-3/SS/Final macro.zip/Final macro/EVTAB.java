class EVTAB{
	int initialValue;
	
	void insert(int value){
		initialValue = value;
	}
}