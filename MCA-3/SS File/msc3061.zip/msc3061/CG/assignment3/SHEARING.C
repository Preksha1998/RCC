#include<stdio.h>
#include<conio.h>
#include<graphics.h>
#include<math.h>
#define size 30
#define Round(a) ((int)(a+0.5))
#define pi 22/7
int free1=1,op,erase_flag=1;
float hs,he,ws,we,h,w,x,y,df_op[size],df_x[size],df_y[size],df_pen_x,df_pen_y,frame_pen_x=0,frame_pen_y=0;
float h1[3][3];
void gentle(int xa,int ya,int xb,int yb){
	int dx,dy,x,y,xend;
	int p,twody,twodydx;
	float m;
	dx=abs(xa-xb);
	dy=abs(ya-yb);
	if(dx==0){
		m=(float)(dy);
	}
	else{
		m=((float)dy/(float)dx);
	}
	p=2*dy-dx;
	twody=2*dy;
	twodydx=2*(dy-dx);
	if(xa>xb){
		x=xb;
		y=yb;
		xend=xa;
	}
	else{
		x=xa;
		y=ya;
		xend=xb;
	}
	putpixel(x,y,1);
	while(x<xend){
		x++;
		if(p<0){
			p=p+twody;
		}
		else{
			if(m>0 && m<1){
				y++;
			}
			else if(m<0 && m>-1){
				y--;
			}
			p=p+twodydx;

		}
		putpixel(x,y,1);
	}

}
void steep(int xa,int ya,int xb,int yb){
	int dx,dy,x,y,yend;
	int p,twodx,twodxdy;
	float m;
	dx=abs(xa-xb);
	dy=abs(ya-yb);
	if(dx==0){
		m=(float)(dy);
	}
	else{
		m=((float)(yb-ya)/(float)(xb-xa));
	}
	p=2*dx-dy;
	twodx=2*dx;
	twodxdy=2*(dx-dy);
	if(ya>yb){
		x=xb;
		y=yb;
		yend=ya;
	}
	else{
		x=xa;
		y=ya;
		yend=yb;
	}
	putpixel(x,y,1);
	while(y<yend){
		y++;
		if(p<0){
			p=p+twodx;
		}
		else{
			if(m>=1){
				x++;
			}
			else if(m<=-1){
				x--;
			}
			p=p+twodxdy;

		}
		putpixel(x,y,1);
	}

}
void putpoint(int op1,float x1,float y1){
	if(free1>size){
		printf("\n DISPLAY FILE IS FULL");
	}
	else{
		df_op[free1]=op1;
		df_x[free1]=x1;
		df_y[free1]=y1;
		free1++;
		//printf("\n%d %f %f",op1,x1,y1);
	}

}
void display_file_enter(int op1){
	putpoint(op1,df_pen_x,df_pen_y);
}
void getpoint(int n){

	op=df_op[n];
	x=df_x[n];
	y=df_y[n];

}

void move_abs(float x1,float y1){
	df_pen_x=x1;
	df_pen_y=y1;
	//printf("%f %f",df_pen_x,df_pen_y);
	display_file_enter(1);
}
void move_rel(float dx,float dy){
	df_pen_x+=dx;
	df_pen_y+=dy;
	display_file_enter(1);
}
void line_abs(float x1,float y1){
	df_pen_x=x1;
	df_pen_y=y1;
	display_file_enter(2);
}
void line_rel(float dx,float dy){
	df_pen_x+=dx;
	df_pen_y+=dy;
	display_file_enter(2);

}
float max(float x1,float y1){
	if(x1>y1){
		return x1;
	}
	else{
		return y1;
	}
}
float min(float x1,float y1){
	if(x1<y1){
		return x1;
	}
	else{
		return y1;
	}
}
void domove(float x1,float y1){
       //	printf("\n%f %f",x1,y1);
	frame_pen_x=max(ws,min(we,(x1*w+ws)));
	frame_pen_y=max(hs,min(he,(y1*h+hs)));
       //	printf("\n %f %f",frame_pen_x,frame_pen_y);
}
void doline(float x2,float y2){
	float x1=frame_pen_x,y1=frame_pen_y;
	int dx,dy;
	frame_pen_x=max(ws,min(we,(x2*w+ws)));
	frame_pen_y=max(hs,min(he,(y2*h+hs)));
       //	printf("\n %f %f",frame_pen_x,frame_pen_y);
	dx=(int)((abs)(x1-frame_pen_x));
	dy=(int)((abs)(y1-frame_pen_y));
	//line((int)(x1),(int)(y1),(int)(frame_pen_x),(int)(frame_pen_y));
	if(dx>dy){
	gentle((int)(x1+0.5),(int)(y1+0.5),(int)(frame_pen_x+0.5),(int)(frame_pen_y+0.5));
	}
	else{
	steep((int)(x1+0.5),(int)(y1+0.5),(int)(frame_pen_x+0.5),(int)(frame_pen_y+0.5));
	}


}
void identity_matrix(){
	int i,j;
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			if(i==j){
				h1[i][j]=1;
			}
			else{
				h1[i][j]=0;
			}
		}
	}
}
void shear_x(float shx){
	h1[1][0]=shx;
}
void shear_y(float shy){
	h1[0][1]=shy;
}
void build_transformation(){
	int i;
	printf("\nENTER 1 FOR X-SHEAR");
	printf("\nENTER 2 FOR Y-SHEAR");
	printf("\nENTER CHOICE::");
	scanf("%d",&i);
	identity_matrix();
	if(i==1)
		shear_x(1);
	else if(i==2)
		shear_y(1);
}
void dopolygon(float x,float y){
	domove(x,y);
}
void interpret(int start,int count){
	int n;
	for(n=start;n<=count;n++){
		getpoint(n);

		if(op==1){
			domove(x,y);
		}
		else if(op==2){
			doline(x,y);
		}
		else{
			dopolygon(x,y);

		}
	}
}

void do_transformation(){
	float temp=x*h1[0][0]+y*h1[1][0]+h1[2][0];
	y=x*h1[0][1]+y*h1[1][1]+h1[2][1];
	x=temp;
}
void gettransformedpoint(int n1){
	getpoint(n1);
	if(op>0 || op<-31){
		do_transformation();
	}
}

void interpret1(int start,int count){
	int n;
	for(n=start;n<=count;n++){
		gettransformedpoint(n);

		if(op==1){
			domove(x,y);
		}
		else if(op==2){
			doline(x,y);
		}
		else{
			dopolygon(x,y);

		}
	}
}
void new_frame(){
	erase_flag=1;
}
void erase(){
	int i,j;
	for(i=0;i<getmaxx();i++){
		for(j=0;j<getmaxy();j++){
			putpixel(i,j,0);
		}
	}
}
void make_picture_current(){
	if(erase_flag==1){
		erase();
	}
	erase_flag=0;
	if(free1>1){
		build_transformation();
		interpret(1,(free1-1));
		interpret1(1,(free1-1));
	}
	free1=1;

}
void poly_abs(int n,float ax[],float ay[]){
	int i;
	if(n<3){
		printf("\nwrong polygon sides");
	}
	df_pen_x=ax[n-1];
	df_pen_y=ay[n-1];
	display_file_enter(n);
	for(i=0;i<n;i++){
		line_abs(ax[i],ay[i]);
	}
}

void initialize(){
	free1=1,
	frame_pen_x=0,
	frame_pen_y=0,
	df_pen_x=0,
	df_pen_y=0,
	hs=0,
	he=getmaxx(),
	h=he-hs,
	ws=0,
	we=getmaxy(),
	w=we-ws;
}
void main(){
	int i,gd=DETECT,gm,n=8;
	//float ax[]={0.5,0.4,0.4,0.5,0.6,0.6};
	//float ay[]={0.4,0.5,0.7,0.6,0.7,0.5};
	float ax[]={0.2,0.2,0.1,0.1,0.4,0.4,0.3,0.3};
	float ay[]={0.1,0.3,0.3,0.4,0.4,0.3,0.3,0.1};

	initgraph(&gd,&gm,"c:/tc/bgi");
	initialize();
	new_frame();
	poly_abs(n,ax,ay);

	make_picture_current();
	/*for(i=1;i<free1;i++){
		printf("\n%f %f %f",df_op[i],df_x[i],df_y[i]);
	} */
	getch();
}