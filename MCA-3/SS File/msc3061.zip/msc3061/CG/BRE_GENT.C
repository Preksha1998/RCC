#include<stdio.h>
#include<conio.h>
#include<graphics.h>
#include<math.h>
