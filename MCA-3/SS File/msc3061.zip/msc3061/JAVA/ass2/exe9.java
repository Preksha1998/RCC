class demo{
	demo(){
		System.out.println("Default Constructer Is Called");
	}
}
class exe9{
	public static void main(String args[]){
	demo d=new demo();
	}

}