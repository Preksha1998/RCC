package gujuni.KS;
public class KSMSC{
	public void firstyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S FIRST YEAR MSC(CA&IT)");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void secondyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S SECOND YEAR MSC(CA&IT)");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void thirdyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S THIRD YEAR MSC(CA&IT)");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void fourthyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S FOURTH YEAR MSC(CA&IT)");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void fifthyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S FIFTH YEAR MSC(CA&IT)");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	

}