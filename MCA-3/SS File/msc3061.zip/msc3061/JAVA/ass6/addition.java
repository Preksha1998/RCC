package calculator;
public class addition{
	public void add(int num1,int num2){
		int ans=num1+num2;
		System.out.println("ADDITION OF 2 NOS IS::"+ans);
	}
}