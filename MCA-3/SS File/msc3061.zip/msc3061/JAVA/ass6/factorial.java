package Number_System;
public class factorial{
	public void getFactorial(){
		int num=5,fact=1;
		while(num>0){
			fact=fact*num;
			num--;
		}
	System.out.println("Factorial is::"+fact);
			
	}	
}
