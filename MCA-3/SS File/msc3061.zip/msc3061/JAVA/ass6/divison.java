package calculator;
public class divison{
	public void div(int num1,int num2){
		int ans;
		if(num2!=0){
		ans=num1/num2;
		System.out.println("DIVISON OF 2 NOS IS::"+ans);
		}
		else{
		System.out.println("DIVISON NOT POSIIBLE");
		}
	}
}