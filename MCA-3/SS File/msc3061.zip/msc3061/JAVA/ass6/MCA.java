package gujuni.ROLLWALA;
public class MCA{
	public void firstyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S FIRST YEAR MCA");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void secondyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S SECOND YEAR MCA");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void thirdyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S THIRD YEAR MCA");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void fourthyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S FOURTH YEAR MCA");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void fifthyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S FIFTH YEAR MCA");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	

}
