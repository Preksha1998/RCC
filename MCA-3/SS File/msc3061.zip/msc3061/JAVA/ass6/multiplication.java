package calculator;
public class multiplication{
	public void mul(int num1,int num2){
		int ans=num1*num2;
		System.out.println("MULTIPLICATION OF 2 NOS IS::"+ans);
	}
}