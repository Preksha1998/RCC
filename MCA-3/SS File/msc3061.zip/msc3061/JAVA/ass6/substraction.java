package calculator;
public class substraction{
	public void sub(int num1,int num2){
		int ans=num1-num2;
		System.out.println("SUBSTRACTION OF 2 NOS IS::"+ans);
	}
}