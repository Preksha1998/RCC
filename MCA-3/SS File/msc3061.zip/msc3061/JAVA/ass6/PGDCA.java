package gujuni.ROLLWALA;
public class PGDCA{
	public void firstyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S FIRST YEAR PGDCA");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void secondyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S SECOND YEAR PGDCA");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void thirdyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S THIRD YEAR PGDCA");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void fourthyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S FOURTH YEAR PGDCA");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	public void fifthyear(){
		System.out.println("--------------------------------");
		System.out.println("IT'S FIFTH YEAR PGDCA");
		System.out.println("IT'S CONSISTING OF 250 STUDENTS");
	}
	

}
