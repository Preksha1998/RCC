class exe3{
	public static void main(String args[]){
		String s="K S ScHOOL OF BUSINESS MANAGEMENT";
		String slower=s.toLowerCase();
		System.out.println(slower);
		/*StringBuffer s1=new StringBuffer("K S ScHOOL OF BUSINESS MANAGEMENT");
		StringBuffer slower1=s1.toLowerCase();
		System.out.println(slower1);*/
	}

}