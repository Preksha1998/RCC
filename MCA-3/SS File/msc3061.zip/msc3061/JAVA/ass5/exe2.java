class exe2{
	public static void main(String args[]){
		String s="I Love India";
		String supper=s.toUpperCase();
		System.out.println(supper);
		/*StringBuffer s1=new StringBuffer("I Love India");
		StringBuffer supper1=s1.toUpperCase();
		System.out.println(supper1);*/
	}

}