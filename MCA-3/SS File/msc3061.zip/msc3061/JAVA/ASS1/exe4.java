
class exe4{
	public static void main(String args[]){
		int num=5;
		int fact=1;
		while(num>0){
			fact=fact*num;
			num--;
		}	
		System.out.println("The Factorial Is::"+fact);
	}
}