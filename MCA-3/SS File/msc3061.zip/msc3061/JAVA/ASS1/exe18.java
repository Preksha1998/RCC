class exe18{
	public static void main(String args[]){
		double n=3,ans=0;
		while(n>0){
			ans+=(1/(n*n));
			n--;
		}
		System.out.println("The Ans Is::"+ans);
	}

}