class exe20{
	public static void main(String args[]){
		int temp,a,b;
		a=10;
		b=20;
		System.out.println("The Value Before Swapping Is::"+a+" "+b);
		temp=a;
		a=b;
		b=temp;
		System.out.println("The Value After Swapping Is::"+a+" "+b);
	}

}