class exe15{
	public static void main(String args[]){
		double ans,ans1,ans2;
		double l,b,h;
		double r=2;
		l=5;
		b=5;
		h=5;
		ans=3.14*r*r;
		System.out.println("The Area Of Cicle Is::"+ans);
		ans1=l*l;
		System.out.println("The Area Of Square Is::"+ans1);
		ans2=0.5*(b*h);
		System.out.println("The Area Of Triangle Is::"+ans2);
		

	}
}