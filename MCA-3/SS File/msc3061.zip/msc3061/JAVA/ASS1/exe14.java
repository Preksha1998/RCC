class exe14{
	public static void main(String args[]){
		double gs=10000,da,hra,basic;
		da=gs*0.5;
		hra=gs*0.10;
		gs=gs+da+hra;
		System.out.println("THE GROSS SALARY IS::"+gs);
		
		
	}


}