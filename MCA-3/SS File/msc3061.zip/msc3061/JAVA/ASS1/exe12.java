class exe12{
	public static void main(String args[]){
		int year=2000;
		if(year%4==0){
			System.out.println("It's A Leap Year");
		}
		else{
			System.out.println("It's Not A Leap Year");
		}	
	}


}