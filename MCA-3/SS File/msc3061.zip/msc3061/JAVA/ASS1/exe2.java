class exe2{
	public static void main(String args[]){
		double ans;
		ans=3.14*2*2;
		System.out.println("The Area Of Cicle Is::"+ans);
		

	}
}