
class exe5{
	public static void main(String args[]){

		int m=2;
		int n=3;
		int p=1;
		while(n>0){
			p=p*m;
			n--;
		}
		System.out.println("The Power Is::"+p);
	}
}