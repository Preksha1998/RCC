class exe11{
	public static void main(String args[]){
		int num=10;
		if(num%2==0){
			System.out.println("The Number Is EVEN");
		}
		else{
			System.out.println("The Number Is ODD");
		}	
	}


}