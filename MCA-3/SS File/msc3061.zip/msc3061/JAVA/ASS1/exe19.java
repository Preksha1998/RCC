class exe19{
	public static void main(String args[]){
		int num=10;
		for(int i=1;i<=10;i++){
			System.out.println(num+" "+"*"+" "+i+" "+"="+" "+num*i);
		}

	}

}