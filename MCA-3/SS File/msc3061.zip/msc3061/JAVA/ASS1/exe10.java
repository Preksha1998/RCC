class exe10{
	public static void main(String args[]){
		System.out.println("The Student's Name Is::Hetvee");
		System.out.println("The Student's Roll-Number Is::3061");
		System.out.println("The Student's Divison Is::A");
	}


}