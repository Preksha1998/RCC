class sample{
	static void demo(){
		System.out.println("EXAMPLE OF STATIC METHOD");
	}
}
class exe8{
	public static void main(String args[]){
		sample.demo();
	}
}