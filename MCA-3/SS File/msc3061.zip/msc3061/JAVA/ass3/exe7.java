class exe7{
	static{
		System.out.println("STATIC BLOCK EXECUTED FAST");
	}
	public static void main(String args[]){
		System.out.println("RUN FROM MAIN");
	}
}