#include<stdio.h>
#include<conio.h>
#include<String.h>
#include<ctype.h>
char tbl[6][5][10]={
	{"nt","<id>","+","*","$"},
	{"e","tx","error","error","error"},
	{"x","error","+tx","error","null"},
	{"t","vy","error","error","error"},
	{"y","error","null","*vy","null"},
	{"v","<id>","error","error","error"}};
static int error=0;
int field_cnt=0;
int arr_size=0;
void main(){

	char input[20],*field,csf[20],crr_field[10],field_arr[20][20]={""};
	char pre_str[50],post_str[10],single_char[2],single_char1[2],c,prediction[20];
	int non_t=0,len,row,column,cnt=0,i,nt,op,cl,r,pos,j,prediction_length;
	clrscr();
	printf("\nTABLE::\n");
	for(i=0;i<6;i++){
		for(j=0;j<4;j++){
			printf("%s\t",tbl[i][j]);
		}
		printf("\n");
	}
	printf("\nENTER THE EXPRESSION::");
	gets(input);
	field=strtok(input," ");
	while(field!=NULL){
		strcpy(field_arr[arr_size],field);
		/*if(arr_size>0)
		{
			if(strcmp(field,field_arr[arr_size-1])==0){
				printf("\nERROR");
				getch();
				return;
			}
		} */
		arr_size++;
		field=strtok(NULL," ");
	}
	if(strcmp(field_arr[arr_size-1],"$")!=0){
		printf("\nEXPRESSION TERMINATION ERROR");
	}
	else{
		strcpy(csf,"e");
		strcpy(crr_field,field_arr[field_cnt]);
		printf("\nCURRENT SENTENTIAL FORM");
		//printf("\n-------------------------------------------------------");
		while(error==0 && non_t==0){
			len=strlen(csf);
			op=0;
			non_t=0;
			cnt=0;
			strcpy(pre_str,'\0');
			strcpy(post_str,'\0');
			for(i=0;i<len;i++){
				nt=0;
				single_char[0]=csf[i];
				single_char[1]='\0';
				if(strcmp(single_char,crr_field)==0){
					cl=0;
					single_char1[0]=csf[i+1];
					single_char1[1]='\0';
					for(r=1;r<6;r++){
						if(strcmp(single_char1,tbl[r][0])==0){
							cl++;
							break;
						}
					}
					if(cl==1){
						field_cnt++;
						op=1;
						strcpy(crr_field,field_arr[field_cnt]);
						break;
					}
				}
				else{
					for(r=1;r<6;r++){
						if(strcmp(single_char,tbl[r][0])==0){
							nt=1;
							row=r;
							if(i!=0){
								strncpy(pre_str,csf,i);
								pre_str[i]='\0';
							}
							if(len>i+1){
								pos=0;
								for(j=i+1;j<len;j++){
									post_str[pos]=csf[j];
									pos++;
								}
								post_str[pos]='\0';
							}
							break;
						}
						else{
							cnt++;
						}

					}
				}
				if(cnt!=len*5){
					if(nt==1){
						for(c=1;c<5;c++){
							if(strcmp(crr_field,tbl[0][c])==0){
								column=c;
								break;
							}
						}
						strcpy(prediction,tbl[row][column]);
						prediction_length=strlen(prediction);
						prediction[prediction_length]='\0';
						printf("\n%s\t\t%s\t\t%s",csf,crr_field,prediction);
						if(strcmp(prediction,"error")!=0){
							if(strcmp(prediction,"null")!=0){
								if(strcmp(prediction,crr_field)==0){
									field_cnt++;
									strcpy(crr_field,field_arr[field_cnt]);

								}
								strcat(prediction,post_str);
								strcat(pre_str,prediction);
								strcpy(csf,pre_str);

							}
							else{
								strcpy(csf,strcat(pre_str,post_str));
							}
						}
						else{
							error=1;
						}
						break;
					}
				}
				else{
					non_t=1;
				}
			}
		}
		if(error==0){
			printf("\nFINAL CURRENT SENTENTIAL FORM IS::%s",csf);
		}
		else{
			printf("\nERROR");
		}
	}
	getch();
}