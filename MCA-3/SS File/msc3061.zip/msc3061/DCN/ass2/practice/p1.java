import java.util.*;
import java.io.*;
import java.new.*;

public class p1
{
	public static void main(String args[])
	{
		try{
			Socket sc=new Socket("localhost",121);
			Scanner s=new Scanner(System.in);
			System.out.printn("Enter Number: ");
			String msg=s.nextLine();
			
			OutputStream os=sc.getOutputStream();
			DataOutputStream
		}
	}
	
}